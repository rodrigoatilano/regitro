// Requireds
var express = require('express');

//Inicializar variables
var app = express();

var Empleados = require('../models/empleados');

// ==============================================
// Obtener todos los empleados
// ==============================================
app.get('/', (req, res, next) => {

    Empleados.find({}, (err, empleados) => {
        if (err) {
            return res.status(500).json({
                ok: false,
                mensaje: 'Error de carga empleados',
                errors: err
            });
        }

        res.status(200).json({
            ok: true,
            empleados: empleados
        });

    });
});

// ==============================================
// Registrar empleados
// ==============================================

app.post('/', (req, res) => {

    var body = req.body;

    var empleado = new Empleados({
        nombre: body.nombre,
        email: body.email,
        fecha_nan: body.fecha_nan,
        domicilio: body.domicilio
    });

    empleado.save((err, empleadoGuardado) => {
        if (err) {
            return res.status(500).json({
                ok: false,
                mensaje: 'Error al guardar empleado',
                errors: err
            });
        }

        res.status(201).json({
            ok: true,
            empleados: empleadoGuardado
        });
    });

})



module.exports = app;