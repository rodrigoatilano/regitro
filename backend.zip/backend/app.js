// Requireds
var express = require('express');
var moongose = require('mongoose');
var bodyParser = require('body-parser');

//Inicializar variables
var app = express();


// Body parser
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

//importar rutas
var appRoutes = require('./routes/app');
var empleadosRoutes = require('./routes/empleados');


//conexinon db
moongose.connection.openUri('mongodb://localhost:27017/employees', (err, res) => {

    if (err) throw err;
    console.log('Base de datos : \x1b[32m%s\x1b[0m', 'running');
});

//rutas
app.use('/empleados', empleadosRoutes);
app.use('/', appRoutes);


//Peticion
app.listen(3000, () => {
    console.log('Express Online : \x1b[32m%s\x1b[0m', 'running');
});