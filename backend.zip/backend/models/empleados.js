var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var empleadosSchema = new Schema({

    nombre: { type: String, required: [true, 'El nombre es obligatorio'] },
    email: { type: String, unique: true, required: [true, 'El correo electrónico es obligatorio'] },
    fecha_nan: { type: String, required: [true, 'El la fecha de nacimiento es necesario'] },
    domicilio: { type: String, required: [true, 'El domicilio es obligatorio'] }
});

module.exports = mongoose.model('Empleados', empleadosSchema);